# Weather-Journal App Project

## Overview
the app response to the user data and give hime the weathre in the area which he provid it's zip.
the weather data received show in Celsius.
when u open the app for the first time u will recived the latest data that the server handled, so we show the last data we proceed and when it was.
ur data would be available only for the first person who use the app after u, be sure it doesn't contain any personal information like ur name or number

## Instructions
to use our app all u need is to inter ur correct zip code and ur feeling then click on the button to receive the data

## structure
the app contains server.js file wich presents the server side code, a readme file (u already found it ⁦⁦;-), u will find a folder called website which hold the webapp files (client side code) this folder contains three mains files; app.js (clint side code JavaScript)
style.css (style sheet for the app)
index.html (well it's the html file that link all our files to eachother).

## external resources
mapweather API

