//creat empty array to hold all the data as a main container 
projectData = [];

// Require Express to run server and routes, set express to variable 

let express = require('express');

let app = express();

//require cors

let cors = require('cors');

//require bodyParser

let bodyParser = require('body-parser');

//use cors

app.use(cors());

//create port

let port = 8080;

//use body parser to creat the middle wear 

app.use(bodyParser.urlencoded({
    extended: false
}));

app.use(bodyParser.json());

// Initialize the main project folder

app.use(express.static('website'));

// Setup Server, running the server

let server = app.listen(port, listening => {

    console.log('server running');

    console.log(`running on localhost:${port}`);
})

;

// get data from the app , receive post requests and save data 

app.post('/addData', addData);

//get the main data, add it to an object as a container then add it to the main container(array)

function addData(req, res) {

    let container = {};

    container.temperature = req.body.temperature;

    container.zipCode = req.body.zipCode;

    container.feeling = req.body.feeling;

    container.time = req.body.time;

    container.city = req.body.place;

    container.country = req.body.country;

    console.log(container);

    //add the object that hold data to the first index in the array so it becomes easier to use it with projectData[0]

    projectData.unshift(container);



}

//send data to the app

app.get('/sendData', sendData);

//send the last data that the server received

function sendData(req, res) {

    res.send(projectData[0]);

    console.log(projectData[0]);

}